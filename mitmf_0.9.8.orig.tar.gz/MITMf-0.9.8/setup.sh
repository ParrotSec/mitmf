#!/usr/bin/env bash

git submodule init && git submodule update --recursive